package bd.edu.seu.productmanagement.service;

import bd.edu.seu.productmanagement.model.Product;
import bd.edu.seu.productmanagement.model.User;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    public void save(User user) {
        String line = user.getId() + "," + user.getName() + "," + user.getPassword() + "\n";
        try {
            RandomAccessFile raf = new RandomAccessFile("users.txt", "rw");
            raf.seek(raf.length());
            raf.writeBytes(line);
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public List<User> list() {
        List<User> userList = new ArrayList<>();
        try {
            RandomAccessFile raf = new RandomAccessFile("users.txt", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                String[] arr = line.split(",");
                int id = Integer.parseInt(arr[0]);
                String name = arr[1];
                String password = arr[2];
                User user = new User(id, name, password);
                userList.add(user);
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return userList;
    }
}
