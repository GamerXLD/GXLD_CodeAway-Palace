package bd.edu.seu.productmanagement.controller;

import bd.edu.seu.productmanagement.model.Product;
import bd.edu.seu.productmanagement.service.ProductService;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ProductController implements Initializable {

    @FXML
    private TextField idField;

    @FXML
    private TextField nameField;

    @FXML
    private TextField priceField;

    @FXML
    private TableView<Product> productTableView;

    @FXML
    private TableColumn<Product, Number> idColumn;

    @FXML
    private TableColumn<Product, String> nameColumn;

    @FXML
    private TableColumn<Product, Number> priceColumn;

    @FXML
    void saveAction(ActionEvent event) {
        int id = Integer.parseInt(idField.getText());
        String name = nameField.getText();
        double price = Double.parseDouble(priceField.getText());

        Product product = new Product(id, name, price);
        ProductService productService = new ProductService();
        productService.save(product);
        System.out.println("Product Saved");


        List<Product> productList = productService.list();

        ObservableList<Product> productObservableList = FXCollections.observableArrayList();
        productObservableList.addAll(productList);

        productTableView.setItems(productObservableList);

        idField.setText("");
        nameField.setText("");
        priceField.setText("");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        idColumn.setCellValueFactory(cell -> new SimpleIntegerProperty(cell.getValue().getId()));
        nameColumn.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getName()));
        priceColumn.setCellValueFactory(c -> new SimpleDoubleProperty(c.getValue().getPrice()));

        ProductService productService = new ProductService();
        List<Product> productList = productService.list();

        ObservableList<Product> productObservableList = FXCollections.observableArrayList();
        productObservableList.addAll(productList);

        productTableView.setItems(productObservableList);
    }
}
