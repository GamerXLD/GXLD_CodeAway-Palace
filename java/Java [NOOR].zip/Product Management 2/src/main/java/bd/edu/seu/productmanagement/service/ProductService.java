package bd.edu.seu.productmanagement.service;

import bd.edu.seu.productmanagement.model.Product;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

public class ProductService {
    public void save(Product product) {
        try {
            String line = product.getId() + "," + product.getName() + "," + product.getPrice() + "\n";
            RandomAccessFile raf = new RandomAccessFile("products.txt", "rw");
            raf.seek(raf.length());
            raf.writeBytes(line);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Product> list() {
        List<Product> productList = new ArrayList<>();
        try {
            RandomAccessFile raf = new RandomAccessFile("products.txt", "r");
            String line;
            while ((line = raf.readLine()) != null) {
                String[] arr = line.split(",");
                int id = Integer.parseInt(arr[0]);
                String name = arr[1];
                double price = Double.parseDouble(arr[2]);

                Product product = new Product(id, name, price);
                productList.add(product);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return productList;
    }
}













