module bd.edu.seu.admissionsystem {
    requires javafx.controls;
    requires javafx.fxml;


    opens bd.edu.seu.admissionsystem to javafx.fxml;
    exports bd.edu.seu.admissionsystem;
}