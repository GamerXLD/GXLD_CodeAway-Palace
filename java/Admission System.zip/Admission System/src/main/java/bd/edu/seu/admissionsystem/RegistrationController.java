package bd.edu.seu.admissionsystem;

import javafx.fxml.FXML;
import javafx.scene.control.*;

public class RegistrationController {
    @FXML
    public TextField nameField;
    @FXML
    public PasswordField passwordField;
    @FXML
    public ChoiceBox<String> programChoiceBox;
    @FXML
    public TextArea biographyArea;
    @FXML
    public CheckBox agreeCheckBox;
    @FXML
    public ToggleGroup genderToggle;


    public static String name;

    @FXML
    public void registration() {
        name = nameField.getText();
        String password = passwordField.getText();
        String biography = biographyArea.getText();
        boolean selected = agreeCheckBox.isSelected();

        System.out.println();

        System.out.println(name);
        HelloApplication.changeScene("welcome");
    }

    @FXML
    public void changeScene() {
        HelloApplication.changeScene("welcome");
    }
}
